package com.nowcoder.community.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MessageMapper {

    // 5.13
    // 查询某个主题下最新的通知
    
    // 查询某个主题所包含的通知数量

    // 查询未读的通知的数量

}
